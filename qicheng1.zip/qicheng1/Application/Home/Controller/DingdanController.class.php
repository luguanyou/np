<?php
namespace Home\Controller;
use Think\Controller;
class DingdanController extends ComController {
   public function dingdan(){
	$this->display();
    }
    public function add(){

        $this->display();

          if(isset($_POST['sub'])){

                  $shouhuo=$_POST['shouhuo'];    // 收件人

                 $city=$_POST['city']; 

                 $type=$_POST['type'];      // 类型

                    $tel=$_POST['tel'];

                 $address=$_POST['address'];

                 $number=$_POST['number']; //              

                 

                 $jiedan=$_POST['jiedan'];     // 联系方式

                 $beizhu=$_POST['beizhu'];        // qq

                 $fahuo=$_POST['fahuo'];  // 联系地址

               
        
        
        /* $data=array(

         'id'=>NULL,

         'shouhuo'=>$shouhuo,

          'city'=>$city,

         'type'=>$type,

         'number'=>$number,

         'kuaidi'=>$kuaidi,

         'beizhu'=>$beizhu,

         'fahuo'=>$fahuo,

         );

         $insert=D('Dingdan');

         $insert->add($data); */

          $time=time();
         $data['shouhuo'] = $shouhuo;
         $data['type'] = $type;
         $data['number'] = $number;
         $data['tel']=$tel;
         $data['address']=$address;
         $data['city'] = $city;
         
         $data['beizhu'] = $beizhu;
         $data['jiedan'] = $jiedan;
         $data['fahuo'] = $fahuo;
         $data['time'] = $time;
         $Mod = D('Dingdan');
        
         $Mod->data($data)->add();
         

         if($Mod){   
         
         $this->success("添加成功");
       /*  $this->redirect('Index/index','',2,'订单添加成功！前往订单管理中心!...页面跳转中...');
*/
     }else{   // 如果注册失败

         echo "<script>alert('添加失败！');</script>";

      }
}

}


  public function manage(){
   


 $m = M('Dingdan');      
        $where = "id>5";
        $count = $m->where($where)->count();
        $p = getpage($count,5);
        $list = $m->field(true)->where($where)->order('id')->limit($p->firstRow, $p->listRows)->select();
        $this->assign('Dingdan', $list); // 赋值数据集
        $this->assign('page', $p->show()); // 赋值分页输出
        $this->display();
  

  }
    
    
    public function edit(){
    	
        $Dingdan=M('Dingdan');
        $id=(int)$_GET['id'];
        

        $list=$Dingdan->where("id=$id")->find(); 
        
        $this->assign('vo',$list);
        $this->display();

     /*   $user=M(‘user');
$id=(int)$_GET[‘id'];
$user=M(‘user');
$list=$user->where(“id=$id”)->find();
$this->assign(‘list',$list);
$this->display();*/


      if(isset($_POST['update']))
 {       $n=D("Dingdan");
         $n->create();
    

         
       if($n->save()){   
        
         
       $this->redirect('Index/index','',2,'订单添加成功！前往订单管理中心!...页面跳转中...');

     }else{   // 如果注册失败

         echo "<script>alert('保存失败！');</script>";

      }

}

 }


    

    public function delete(){
        $Dingdan=D('Dingdan');
         $id=(int)$_GET['id'];
        $del=$Dingdan->where("id=$id")->delete();
    	if ($del) {
         $this->success("删除成功");
        }
    }
    
}