<?php
namespace Home\Controller;
use Think\Controller;
class LoginController extends Controller {

public function login(){
  $this->display();
}
public function log()
{
 
 
  $a = 1;
   
  
     if ($a) {
       
        session('username',$user);
       session('uid',1);
      
         
     $this->success('登录成功',U('Index/index'),1);

     }else
     {
      $this->error('对不起,您的密码或用户名错误', U('Login/login'),1);
     }

     
 
          

}

public function logout(){
      
            //D('Member')->logout();
            session('username',null);
            session('[destroy]');
            $this->success('退出成功！', U('Home/Login/login'),1);
        
    }

public function chaxun(){
      $this->display();
    
   
}
      
      
    
    public function chaxun_show(){

         if(isset($_POST['chaxun'])){

        $shouhuo=$_POST['shouhuo']; 
        
        $Dingdan = D("Danhao"); // 实例化User对象
       $condition['shouhuo'] = $shouhuo;
    
 // 把查询条件传入查询方法
     $list=$Dingdan->where($condition)->select(); 
      $this->assign('dingdan',$list);
      $this->display();
    }
}


	}