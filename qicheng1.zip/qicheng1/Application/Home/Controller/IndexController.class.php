<?php
namespace Home\Controller;
use Think\Controller;
 
use PHPExcel_IOFactory;
use PHPExcel;
use Behavior;
class IndexController extends ComController {


 
  




 public function index(){
	
     $m = M('Dingdan');      
        $where = "id>5";
        $count = $m->where($where)->count();
        $p = getpage($count,5);
        $list = $m->field(true)->where($where)->order('id')->limit($p->firstRow, $p->listRows)->select();
        $this->assign('list', $list); // 赋值数据集
        $this->assign('page', $p->show()); // 赋值分页输出
        $this->display();


    }
    public function upindex()
    {
    	$this->display();
    }
public function upload() {
ini_set('memory_limit','1024M');
if (!empty($_FILES)) {
$config = array(
'exts' => array('xlsx','xls'),
'maxSize' => 3145728000,
'rootPath' =>"./Public/",
'savePath' => 'Uploads/',
'subName' => array('date','Ymd'),
);
$upload = new \Think\Upload($config); 
if (!$info = $upload->upload()) {
$this->error($upload->getError());
}
vendor("PHPExcel.PHPExcel");
$file_name=$upload->rootPath.$info['photo']['savepath'].$info['photo']['savename'];
$extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));//判断导入表格后缀格式
if ($extension == 'xlsx') {
$objReader =\PHPExcel_IOFactory::createReader('Excel2007');
$objPHPExcel =$objReader->load($file_name, $encode = 'utf-8');
} else if ($extension == 'xls'){
$objReader =\PHPExcel_IOFactory::createReader('Excel5');
$objPHPExcel =$objReader->load($file_name, $encode = 'utf-8');
}
$sheet =$objPHPExcel->getSheet(0);
$highestRow = $sheet->getHighestRow();//取得总行数
$highestColumn =$sheet->getHighestColumn(); //取得总列数
D('Danhao')->execute('truncate table danhao');
for ($i = 2; $i <= $highestRow; $i++) {
//看这里看这里,前面小写的a是表中的字段名，后面的大写A是excel中位置
//$data['id'] =$objPHPExcel->getActiveSheet()->getCell("A" . $i)->getValue();
$data['danhao'] =$objPHPExcel->getActiveSheet()->getCell("A" .$i)->getValue();
$data['shouhuo'] =$objPHPExcel->getActiveSheet()->getCell("B" .$i)->getValue();
$data['kuaidi'] = $objPHPExcel->getActiveSheet()->getCell("C". $i)->getValue();
//看这里看这里,这个位置写数据库中的表名
$data['day'] =$objPHPExcel->getActiveSheet()->getCell("D" . $i)->getValue();
D('danhao')->add($data);
}
$this->success('导入成功!');
} else {
$this->error("请选择上传的文件");
}
}

public function excel()
 {

         

//创建对象
         vendor("PHPExcel.PHPExcel");
         $excel =  new \PHPExcel();


//Excel表格式,这里简略写了8列
         $letter = array('A', 'B', 'C', 'D', 'E', 'F', 'F', 'G','H','I','J','K','L','M','N','O','P','Q','R','S','T');
//表头数组
         $tableheader = array('id','收件人', '电话号码', '地址','城市','类型','数量','快递','单号','接单人','备注','时间','是否发货');
//填充表头信息
         for ($i = 0; $i < count($tableheader); $i++)
         {
                 $excel->getActiveSheet()->setCellValue("$letter[$i]1", "$tableheader[$i]");
         }
             //在这里调用你要导出的数据
                 $MsgModel = D('Dingdan'); // 实例化Msg对象
                $list = $MsgModel->select();

         //表格数组
              /* $data = array(
                       array('1', '小王', '男', '20', '100'),
                       array('2', '小李', '男', '20', '101'),
                      array('3', '小张', '女', '20', '102'),
                      array('4', '小赵', '女', '20', '103')
                );
                */
               
                $data = $list;
//填充表格信息
         for ($i = 2; $i <= count($data) + 1; $i++)
         {
                 $j = 0;
                 foreach ($data[$i - 2] as $key => $value)
                 {
                         $excel->getActiveSheet()->setCellValue("$letter[$j]$i", "$value");
                         $j++;
                 }
         }
         //创建Excel输入对象
         $write = new \PHPExcel_Writer_Excel5($excel);
         header("Pragma: public");
         header("Expires: 0");
         header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
         header("Content-Type:application/force-download");
         header("Content-Type:application/vnd.ms-execl");
         header("Content-Type:application/octet-stream");
         header("Content-Type:application/download");
         header('Content-Disposition:attachment;filename="testdata.xls"');
         header("Content-Transfer-Encoding:binary");
         $write->save('php://output');
 }

 




}