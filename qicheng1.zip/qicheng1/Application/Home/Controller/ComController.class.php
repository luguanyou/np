<?php
namespace Home\Controller;
use Think\Controller;
class ComController extends Controller {

public function _initialize(){
        //判断用户是否已经登录
        if (!isset($_SESSION['uid'])) {
            $this->error('对不起,您还没有登录!请先登录再进行浏览', U('Login/login'),1);
        }
    }


		}