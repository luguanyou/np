<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>登录</title>
	<style type="text/css">
		#main{
     position: absolute;
    top: 10%;
    height: 240px;
    margin-left: 550px;
    margin-top: -20px; /* 盒子本身高度的一半 */
    }

	</style>
</head>
<body>
  <div>
	<div id="main">

<h2 align="center">用户登录中心</h2>

<form action="/thinkphp323full/index.php/Home/Index/denglu" method="post">

<table id="tbdl">

<tr>

<td>用户名：</td>

<td><input type="text" name="uname" size="20"></td>

</tr>

<tr>

           <td>密&nbsp;&nbsp;码：</td>

           <td><input type="password" name="upwd"></td>
</tr>

<tr>

           <td colspan="2"><center>

           <input type="submit" name="sub" value="登录">

           <input type="reset" name="ret" value="重置">

          </center>

           </td>

</tr>

</table>

</form>

</div>
</div>
</body>
</html>