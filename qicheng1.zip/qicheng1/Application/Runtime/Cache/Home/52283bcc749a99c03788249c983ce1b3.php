<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link href="/thinkphp323full/Public/CSS/front_manage.css" rel="stylesheet" type="text/css" />
	<title>查询结果</title>
</head>
<body>
	<h2 align="center">快递单号查询</h2>
	<div align="center">
	<form action="/thinkphp323full/index.php/Home/Login/chaxun_show" method="post" />
	请输入收件人姓名：<input type="text" name="shouhuo"/>
    <input type="submit" name="chaxun" value="查询" />
	</form>
	</div>
</br>
</br>
	<?php if(is_array($dingdan)): $i = 0; $__LIST__ = $dingdan;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><table class="list" align="center">
			<tr>
				<th>收件人</th>	 	 	
				<th>快递</th>
				<th>快递单号</th>
				<th>发货时间</th>
			</tr>
				
			<tr>
				<td>&nbsp;<?php echo ($vo["shouhuo"]); ?></td>
				<td>&nbsp;<?php echo ($vo["kuaidi"]); ?></td>
				<td>&nbsp;<?php echo ($vo["danhao"]); ?></td>
				<td>&nbsp;<?php echo ($vo["day"]); ?></td>
				
			</tr>	
      
    </table><?php endforeach; endif; else: echo "" ;endif; ?>

	</br></br></br></br>
	<div align="center">
		谢谢您选择我家赣南脐橙，如有不满意，请您及时反馈。
	</div>
</body>
</html>