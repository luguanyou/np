<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>订单管理中心</title>
	<link href="/thinkphp323full/Public/CSS/front_main.css" rel="stylesheet" type="text/css" /> 
	
</head>
<body>
<div id="head">
			<p>订单管理中心</p>
		<!-- </ul> -->
		<div id="login">
			<?php echo ($_SESSION['username']); ?>
			管理员： <?php echo (session('id')); ?> <a href="<?php echo U('Home/Login/logout');?>">[注销]</a>
		</div>

</div>
<div id="clear"></div>
	<div class="Content">
	<div id="side">
   
	<ul class="nav">
		<li><a href="<?php echo U('Home/Dingdan/add');?>">增加新订单</a></li></br></br>
		
		<li><a href="<?php echo U('Home/Dingdan/manage');?>">修改订单</a></li></br></br>
		<li><a href="<?php echo U('Home/Dingdan/manage');?>">删除订单</a></li></br></br>
		<li><a href="<?php echo U('Home/Login/chaxun');?>">查询订单</a></li></br></br>
		<li><a href="<?php echo U('upindex');?>">导入导出订单</a></li>
	</ul>
	</div>
	<div id="main">
		<h1 align="center">欢迎进入订单管理系统</h1>
		<table class="list">
			<tr>
				<th>收件人</th>	 	 	
				<th>收件城市</th>
				<th>类型</th>
				<th>数量</th>
				<th>快递</th>
				<th>接单人</th>
				<th>备注</th>
				<th>接单日期</th>
				<th>是否发货</th>
			</tr>
				<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
				<td>&nbsp;<?php echo ($vo["shouhuo"]); ?></td>
				<td>&nbsp;<?php echo ($vo["city"]); ?></td>
				<td>&nbsp;<?php echo ($vo["type"]); ?></td>
				<td>&nbsp;<?php echo ($vo["number"]); ?></td>
				<td>&nbsp;<?php echo ($vo["kuaidi"]); ?></td>
				<td>&nbsp;<?php echo ($vo["jiedan"]); ?></td>
				<td>&nbsp;<?php echo ($vo["beizhu"]); ?></td>
				<td>&nbsp;<?php echo (date('Y-m-d',$vo["time"])); ?></td>
				<td>&nbsp;<?php echo ($vo["fahuo"]); ?></td>
				
			</tr><?php endforeach; endif; else: echo "" ;endif; ?>
     <tr class="content">
        <!--<td colspan="3" bgcolor="#FFFFFF"> <?php echo ($page); ?></td>-->
        <td colspan="3" bgcolor="#FFFFFF"><div class="pages">
            <?php echo ($page); ?>
        </div></td>
      </tr>

    </table>
	</div>
	</div>
</body>
</html>