<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE html >

<head>
<link href="/thinkphp323full/Public/CSS/front_manage.css" rel="stylesheet" type="text/css" />

<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
<title>修改订单</title>
<style type="text/css">
  input
  {
width:300px;height:30px;
    }
</style>
</head>

<body>

<div id="head">
 
<p>订单管理系统</p>
   
   
   
</div>
<div id="content">
<div id="left">
  <ul class="nav">
     <li><a href="/thinkphp323full/index.php/Home/Dingdan/edit">修改新订单</a></li></br></br>
     <li><a href="">管理订单</a></li></br></br>
     <li><a href="/thinkphp323full/index.php/Index/index">订单管理中心</a></li>
   </ul>
</div>
<div id="form">
  <form id="form1"  method="post" action="/thinkphp323full/index.php/Home/Dingdan/edit">
  <input type="hidden" name="id" value="<?php echo ($vo["id"]); ?>" />
      <table width="1000" border="0" cellpadding="8" cellspacing="1">
        <tr>
          <td colspan="2" align="center">修改订单</td>
          </tr>
        <tr>
          <td width="120">收件人</td>
          <td width="700"><label for="title"></label>
            <input type="text"  name="shouhuo" value="<?php echo ($vo["shouhuo"]); ?>" /></td>
        </tr>
        <tr>
          <td>收货城市</td>
          <td><input type="text"  name="city" value="<?php echo ($vo["city"]); ?>" /></td>
        </tr>
        
            <tr>
          <td>类型：</td>
          <td><input type="text"  name="type" value="<?php echo ($vo["type"]); ?>" /></td>
        </tr>
       
       <tr>
          <td>数量：</td>
          <td><input type="text"  name="number" value="<?php echo ($vo["number"]); ?>" /></td>
        </tr>
        
                    
               <tr>
               <td>备注</td>
               <td><input type="text"  name="beizhu" value="<?php echo ($vo["beizhu"]); ?>" /></td>
               </tr> 

                <tr>
          <td>快递</td>
          <td><input type="text"  name="kuaidi" value="<?php echo ($vo["kuaidi"]); ?>" /></td>
               </tr> 
      
              

               <tr>
          <td>接单人</td>
          <td><input type="text"  name="jiedan" value="<?php echo ($vo["jiedan"]); ?>"  /></td>
               </tr>    
               
        
               <tr>
                        <td>是否已发货：</td>
                        <td>
                            <input type="radio" id="sex" name="fahuo" value="是">是
                            <input type="radio" id="sex" name="fahuo" value="否">否
                        </td>
                    </tr>

          
        <tr>
          <td colspan="2" align="right"><input type="submit" name="update" id="button" value="保存" /></td>
          </tr>
      </table>
    
    </form>
   </div>
 </div>
  

  

</body>
</html>