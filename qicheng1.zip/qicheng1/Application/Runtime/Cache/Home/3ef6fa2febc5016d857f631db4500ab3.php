<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>订单查询</title>
</head>
<body>
	<h2 align="center">快递单号查询</h2>
	<div align="center">
	<form action="<?php echo U('chaxun_show');?>" method="post" />
	请输入收货人姓名：<input type="text" name="shouhuo"/>
    <input type="submit" name="chaxun" value="查询" />
	</form>
  </div>
	<?php if(is_array($dingdan)): $i = 0; $__LIST__ = $dingdan;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><table class="list">
			<tr>
				<th>收件人</th>	 	 	
				<th>收货城市</th>
				<th>类型</th>
				<th>数量</th>
				<th>快递</th>
				<th>接单人</th>
				<th>接单日期</th>
				<th>是否发货</th>
			</tr>
				
			<tr>
				<td>&nbsp;<?php echo ($vo["shouhuo"]); ?></td>
				<td>&nbsp;<?php echo ($vo["city"]); ?></td>
				<td>&nbsp;<?php echo ($vo["type"]); ?></td>
				<td>&nbsp;<?php echo ($vo["number"]); ?></td>
				<td>&nbsp;<?php echo ($vo["kuaidi"]); ?></td>
				<td>&nbsp;<?php echo ($vo["jiedan"]); ?></td>
				<td>&nbsp;<?php echo ($vo["beizhu"]); ?></td>
				<td>&nbsp;<?php echo (date('Y-m-d',$vo["time"])); ?></td>
				<td>&nbsp;<?php echo ($vo["fahuo"]); ?></td>
			</tr>	
      
    </table><?php endforeach; endif; else: echo "" ;endif; ?>
</body>
</html>