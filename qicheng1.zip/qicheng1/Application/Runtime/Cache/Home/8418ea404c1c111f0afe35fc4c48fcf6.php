<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html >
<html>
<head>
<link href="/thinkphp323full/Public/CSS/front_manage.css" rel="stylesheet" type="text/css" />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>添加订单</title>
<style type="text/css">
  input
  {
width:300px;height:30px;
    }
</style>
</head>

<body>
<div id="head">
 
<p>订单管理系统</p>
   
   
   
</div>
<div id="content">
<div id="left">
  <ul class="nav">
     <li><a href="/thinkphp323full/index.php/Home/Dingdan/add.html">增加新订单</a></li>
     <li><a href="<?php echo U('manage');?>">管理订单</a></li>
     <li><a href="<?php echo U('Home/Index/index');?>">订单管理中心</a></li>
   </ul>
</div>
<div id="form"><form id="form1"  method="post" action="/thinkphp323full/index.php/Home/Dingdan/add">
      <table width="1000" border="0" cellpadding="8" cellspacing="1">
        <tr>
          <td colspan="2" align="center">增加新订单</td>
          </tr>
        <tr>
          <td width="120">收件人</td>
          <td width="700"><label for="title"></label>
            <input type="text"  name="shouhuo" id="title" /></td>
        </tr>
        <tr>
          <td>电话</td>
          <td><input type="text"  name="tel"  /></td>
        </tr>
        <tr>
          <td>收货地址</td>
          <td ><input type="text"  name="address"  /></td>
        </tr>
        <tr>
          <td>收货城市</td>
          <td><input type="text"  name="city"  /></td>
        </tr>
        
        <tr>
                        <td>类型：</td>
                        <td><select name="type" >
                           
                            <option value="10斤标准">10斤标准</option>
                            <option value="10斤精品">10斤精品</option>
                            <option value="10斤标准带叶">10斤标准带叶</option>
                            <option value="10斤精品带叶">10斤精品带叶</option>
                            <option value="20斤标准">20斤标准</option>
                            <option value="20斤精品">20斤精品</option>
                            <option value="20斤标准带叶">20斤标准带叶</option>
                            <option value="20斤精品带叶">20斤精品带叶</option>
                        </select></td>
                    </tr>
                    <tr>
                    	<td>数量:</td>
                    	<td>
                    		<select name="number" >
                           
                            <option value="1">1箱</option>
                            <option value="2">2箱</option>
                            <option value="3">3箱</option>
                            <option value="4">4箱</option>
                            <option value="5">5箱</option>
                            <option value="6">6箱</option>
                            <option value="7">7箱</option>
                            <option value="8">8箱</option>
                            <option value="9">9箱</option>
                            <option value="10">10箱</option>
                            <option value="11">11箱</option>
                            <option value="12">12箱</option>
                            <option value="13">13箱</option>
                            <option value="14">14箱</option>
                            <option value="15">15箱</option>
                        </select>
                    	</td>
                    </tr>
               <tr>
               <td>备注</td>
               <td><input type="text"  name="beizhu"  /></td>
               </tr> 

                <tr>
                        <td>接单人：</td>
                        <td><select name="jiedan" >
                           
                            <option value="卢官有">卢官有</option>
                            <option value="卢健">卢健</option>
                            <option value="卢楠">卢楠</option>
                            <option value="代理">代理</option>
                            <option value="其他">其他</option>
                           
                        </select></td>
                    </tr>

              
               
        
               <tr>
                        <td>是否已发货：</td>
                        <td>
                            <input type="radio" id="yes" name="fahuo" value="是">是
                            <input type="radio" id="yes" name="fahuo" value="否">否
                        </td>
                    </tr>

          
        <tr>
          <td colspan="3" align="center"><input type="submit" name="sub" id="button" value="提交" /></td>
          </tr>
      </table>
    </form>
   </div>
 </div>
  

  

</body>
</html>