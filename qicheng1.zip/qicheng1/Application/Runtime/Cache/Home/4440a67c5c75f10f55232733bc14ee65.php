<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>订单管理</title>
	<link href="/thinkphp323full/Public/CSS/front_manage.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="head">
 
<p>订单管理系统</p>
   
   
   
</div>
<div id="content">
<div id="left">
  <ul class="nav">
    
     <li><a href="/thinkphp323full/index.php/Home/Dingdan/manage.html">订单管理</a></li><br/></br></br>
     <li><a href="<?php echo U('Home/Index/index');?>">订单管理中心</a></li>
   </ul>
</div>

	<div id="main">
		
		<table class="list">
			<tr>
				<th>收件人</th>	 	 	
				<th>收货城市</th>
				<th>类型</th>
				<th>数量</th>
				<th>快递</th>
				<th>接单人</th>
				<th>备注</th>
				<th>接单日期</th>
				<th>是否发货</th>
				<th>操作</th>
			</tr>
				<?php if(is_array($Dingdan)): $i = 0; $__LIST__ = $Dingdan;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
				<td>&nbsp;<?php echo ($vo["shouhuo"]); ?></td>
				<td>&nbsp;<?php echo ($vo["city"]); ?></td>
				<td>&nbsp;<?php echo ($vo["type"]); ?></td>
				<td>&nbsp;<?php echo ($vo["number"]); ?></td>
				<td>&nbsp;<?php echo ($vo["kuaidi"]); ?></td>
				<td>&nbsp;<?php echo ($vo["jiedan"]); ?></td>
				<td>&nbsp;<?php echo ($vo["beizhu"]); ?></td>
				<td>&nbsp;<?php echo (date('Y-m-d',$vo["time"])); ?></td>
				<td>&nbsp;<?php echo ($vo["fahuo"]); ?></td>
				
				<td><a href="/thinkphp323full/index.php/Home/Dingdan/edit/id/<?php echo ($vo["id"]); ?>">[编辑]</a>&nbsp;&nbsp;<a href="/thinkphp323full/index.php/Home/Dingdan/delete/id/<?php echo ($vo["id"]); ?>">[删除]</a></td>
			</tr><?php endforeach; endif; else: echo "" ;endif; ?>
       <tr class="content">
        <!--<td colspan="3" bgcolor="#FFFFFF"> <?php echo ($page); ?></td>-->
        <td colspan="3" bgcolor="#FFFFFF"><div class="pages">
            <?php echo ($page); ?>
        </div></td>
      </tr>
    </table>
   
   
	</div>
	
</body>
</html>